﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopBridgeDAL
{
    public class ShopBridgeRepository
    {

        private ShopBridgeEntities Context { get; set; }
        public ShopBridgeRepository()
        {
            Context = new ShopBridgeEntities();
        }

        public List<Inventory> GetInventoriesUsingLinq()
        {
            List<Inventory> lstCategories = null;
            try
            {
                lstCategories = (from c in Context.Inventories

                                 select c).ToList<Inventory>();
            }
            catch (Exception ex)
            {
                lstCategories = null;
            }
            return lstCategories;
        }

        public int UpdateItemOfInventory(string name, decimal price, int quantity)
        {
            var i = 0;
            try
            {
                i = Context.usp_UpdateItemInInventory(name, price, quantity);
                return i;
            }
            catch (Exception)
            {
                return -99;
            }
            //return 1;
        }

        public int AddItemToInventory(string name, string description, decimal price, int quantity, string category, string location, string status)
        {
            try
            {
                List<Inventory> lstCategories = null;
             
                lstCategories = (from c in Context.Inventories

                                    select c).ToList<Inventory>();
                HashSet<string> lstOfNames = new HashSet<string>();
                foreach(var i in lstCategories)
                {
                    lstOfNames.Add(i.Name);
                }
                
                if(!lstOfNames.Contains(name))
                {
                    var i = Context.usp_AddItemToInventory(name, description, price, quantity, category, location, status);
                    return i;

                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                return -99;
            }

        }

        public int DeleteItemFromInventory(string name)
        {
            var i = 0;
            try
            {
                i = Context.usp_DeleteItemInInventory(name);
                return i;
            }
            catch (Exception)
            {
                return -99;
            }

        }
    }
}
