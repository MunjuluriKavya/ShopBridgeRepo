-- List all items in the inventory

IF OBJECT_ID('usp_ListAllItemsInInventory', 'P') IS NULL
BEGIN
  EXEC ('CREATE PROCEDURE usp_ListAllItemsInInventory AS SET NOCOUNT ON;')
END
GO

RAISERROR ('CREATING PROCEDURE usp_ListAllItemsInInventory', 10, 0) WITH NOWAIT;
GO


ALTER PROCEDURE [usp_ListAllItemsInInventory] 
AS
BEGIN
  SET NOCOUNT ON

  BEGIN TRY
    BEGIN
      BEGIN
      TRAN
        SELECT * FROM Inventory 
		
      COMMIT
      RETURN 1
    END
  END TRY

  BEGIN CATCH
    RETURN -99
  END CATCH
END
GO



--DECLARE @ReturnValue1 int
--EXEC @ReturnValue1 = usp_ListAllItemsInInventory 							

--SELECT
--@ReturnValue1 AS ReturnValue

--SELECT * FROM Inventory