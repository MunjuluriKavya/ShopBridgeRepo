CREATE DATABASE Inventory 

CREATE TABLE Inventory 
(
[Id] INT CONSTRAINT pk_Id PRIMARY KEY IDENTITY,
[Name] VARCHAR(30) NOT NULL,
[Description] VARCHAR(50) NOT NULL,
[Price] MONEY CONSTRAINT chk_Price CHECK([Price]>=0) NOT NULL,
[Quantity] INT NOT NULL,
[Category] VARCHAR(20) CONSTRAINT chk_Category CHECK([Category] IN ('RawMaterial', 'WorkInProgress','FinishedGood')) NOT NULL,
[Location] VARCHAR(20),
[Status] VARCHAR(10) NOT NULL
)
GO



--INSERT INTO Inventory ( Name, Description, Price, Quantity, Category, Location, Status) 
--VALUES  ('Flour', 'Flour used for bread making', 40,10,'RawMaterial','WareHouse','NotSold'),
--  		('Butter', 'Flour used for bread making', 40,10,'RawMaterial',null, 'NotSold'),
--		('BreadDough', 'Flour used for bread making', 40,10,'WorkInProgress','WareHouse', 'NotSold'),
--		('Bread', 'Flour used for bread making', 40,10,'FinishedGood','InTransit','Sold')


--TRUNCATE TABLE Inventory
--SELECT * FROM Inventory
--DROP TABLE Inventory


