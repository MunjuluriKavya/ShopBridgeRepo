-- Update an item in the inventory

IF OBJECT_ID('usp_UpdateItemInInventory', 'P') IS NULL
BEGIN
  EXEC ('CREATE PROCEDURE usp_UpdateItemInInventory AS SET NOCOUNT ON;')
END
GO

RAISERROR ('CREATING PROCEDURE usp_UpdateItemInInventory', 10, 0) WITH NOWAIT;
GO


ALTER PROCEDURE [usp_UpdateItemInInventory] @Name varchar(30),
@Price money,
@Quantity int
AS
BEGIN
  SET NOCOUNT ON

  BEGIN TRY
	IF NOT EXISTS (SELECT Name FROM Inventory WHERE [Name] = @Name)
		RETURN -1

    BEGIN
      BEGIN
      TRAN
        UPDATE Inventory SET Price = @Price, Quantity = @Quantity WHERE [Name] = @Name 
		
      COMMIT
      RETURN 1
    END
  END TRY

  BEGIN CATCH
    RETURN -99
  END CATCH
END
GO

--DECLARE @ReturnValue int
--EXEC @ReturnValue = usp_UpdateItemInInventory 'SandalWood',
--										560,
--										2

--SELECT
--@ReturnValue AS ReturnValue

--SELECT * FROM Inventory