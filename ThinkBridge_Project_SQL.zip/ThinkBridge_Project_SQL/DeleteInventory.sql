-- Delete an item in the inventory

IF OBJECT_ID('usp_DeleteItemInInventory', 'P') IS NULL
BEGIN
  EXEC ('CREATE PROCEDURE usp_DeleteItemInInventory AS SET NOCOUNT ON;')
END
GO

RAISERROR ('CREATING PROCEDURE usp_DeleteItemInInventory', 10, 0) WITH NOWAIT;
GO



ALTER PROCEDURE [usp_DeleteItemInInventory] @Name varchar(30)
AS
BEGIN
  SET NOCOUNT ON

  BEGIN TRY
	IF NOT EXISTS (SELECT Name FROM Inventory WHERE [Name] = @Name)
		RETURN -1
    
    BEGIN
      BEGIN
      TRAN
        DELETE FROM Inventory  WHERE [Name] = @Name
		
      COMMIT
      RETURN 1
    END
  END TRY

  BEGIN CATCH
    RETURN -99
  END CATCH
END
GO



--DECLARE @ReturnValue1 int
--EXEC @ReturnValue1 = usp_DeleteItemInInventory 'SandalWood'							

--SELECT
--@ReturnValue1 AS ReturnValue

--SELECT * FROM Inventory