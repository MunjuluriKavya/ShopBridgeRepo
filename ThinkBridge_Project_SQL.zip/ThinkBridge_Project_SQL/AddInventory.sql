-- Add a new item to the inventory

IF OBJECT_ID('usp_AddItemToInventory', 'P') IS NULL
BEGIN
  EXEC ('CREATE PROCEDURE usp_AddItemToInventory AS SET NOCOUNT ON;')
END
GO

RAISERROR ('CREATING PROCEDURE usp_AddItemToInventory', 10, 0) WITH NOWAIT;
GO


ALTER PROCEDURE [usp_AddItemToInventory] @Name varchar(30),
@Description varchar(50),
@Price money,
@Quantity int,
@Category varchar(20),
@Location varchar(20),
@Status varchar(10)
AS
BEGIN
  SET NOCOUNT ON

  BEGIN TRY
    IF @Name = NULL
      RETURN -1
    IF @Description = NULL
      RETURN -2
    IF @Price = NULL
      OR @Price < 0
      RETURN -3
    IF @Quantity = NULL
      RETURN -4
    IF @Category = NULL
      OR @Category NOT IN ('RawMaterial', 'WorkInProgress', 'FinishedGood')
      RETURN -5
    IF @Status = NULL
      RETURN -6
    BEGIN
      BEGIN
      TRAN
        INSERT INTO Inventory (Name, Description, Price, Quantity, Category, Location, Status)
          VALUES (@Name, @Description, @Price, @Quantity, @Category, @Location, @Status)
      COMMIT
      RETURN 1
    END
  END TRY

  BEGIN CATCH
    RETURN -99
  END CATCH
END

--DECLARE @ReturnValue int
--EXEC @ReturnValue = usp_AddItemToInventory 'SandalWood',
--										'SandalWood',
--										560,
--										1,
--										'RawMaterial',
--										'WareHouse',
--										'NotSold'

--SELECT
--@ReturnValue AS ReturnValue

--SELECT * FROM Inventory