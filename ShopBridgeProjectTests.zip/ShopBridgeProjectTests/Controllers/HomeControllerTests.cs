﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ShopBridgeProject.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rhino.Mocks;
using ShopBridgeDAL;
using ShopBridgeProject.Models;
using System.Web.Mvc;

namespace ShopBridgeProject.Controllers.Tests
{
    [TestClass()]
    public class HomeControllerTests
    {
        MockRepository mocks;
        HomeController homeControllerObj;
        ShopBridgeRepository shopBridgeBL;
        ShopBridgeEntities entity;

        public void HomeTestConfiguration()
        {
            mocks = new MockRepository();
            shopBridgeBL = mocks.StrictMock<ShopBridgeRepository>();
            homeControllerObj = new HomeController();
        }

        [TestMethod()]
        public void IndexTest()
        {
            HomeTestConfiguration();
            var actual = homeControllerObj.Index() as ViewResult;
            Assert.AreEqual("Welcome to HomePage", actual.ViewData.Values.First());
        }

        [TestMethod()]
        public void AddInventoryTest()
        {
            HomeTestConfiguration();
            Assert.Fail();
        }

        [TestMethod()]
        public void ViewInventoriesTest()
        {
            HomeTestConfiguration();

            List<Inventory> listOfInventories = shopBridgeBL.GetInventoriesUsingLinq();
            List<InventoryModel> lstInventory = new List<InventoryModel>();
            foreach (Inventory item in listOfInventories)
            {
                InventoryModel inventory = new InventoryModel();
                inventory.Id = item.Id;
                inventory.Name = item.Name;
                inventory.Description = item.Description;
                inventory.Price = item.Price;
                inventory.Quantity = item.Quantity;
                inventory.Category = item.Category;
                inventory.Location = item.Location;
                inventory.Status = item.Status;
                lstInventory.Add(inventory);

            }

             var actual = homeControllerObj.ViewInventories() as ViewResult;
             Assert.AreEqual("ViewInventories", actual.ViewName);
        }

        [TestMethod()]
        public void SaveUpdateInventoryFailureTest()
        {
            HomeTestConfiguration();
            InventoryModel inventory = new InventoryModel();
            inventory.Name = "Flour";
            inventory.Price = 15;
            inventory.Quantity = 35;

            var actual = homeControllerObj.SaveUpdateInventory(inventory) as ViewResult;
            Assert.AreNotEqual("ViewInventories", actual.ViewName); 
        }

        [TestMethod()]
        public void SaveUpdateInventoryTest()
        {
            HomeTestConfiguration();
            InventoryModel inventory = new InventoryModel();
            inventory.Name = "Flour";
            inventory.Price = 18;
            inventory.Quantity = 35;

            var actual = homeControllerObj.SaveUpdateInventory(inventory) as ViewResult;
            Assert.AreEqual("Success", actual.ViewName);
        }

        [TestMethod()]
        public void SaveUpdateInventoryMessageTest()
        {
            HomeTestConfiguration();
            InventoryModel inventory = new InventoryModel();
            inventory.Name = "Flour";
            inventory.Price = 17;
            inventory.Quantity = 35;

            var actual = homeControllerObj.SaveUpdateInventory(inventory) as ViewResult;
            var message = actual.ViewData.Values.First();
            Assert.AreEqual("Inventory has been updated successfully.", message);
        }

        [TestMethod()]
        public void UpdateInventorySuccessTest()
        {
            HomeTestConfiguration();
            InventoryModel inventory = new InventoryModel();
            inventory.Name = "Flour";
            inventory.Price = 16;
            inventory.Quantity = 35;

            var actual = homeControllerObj.UpdateInventory(inventory.Name,inventory.Price,inventory.Quantity) as ViewResult;
            Assert.AreEqual("UpdateInventory", actual.ViewName);
            
        }

        [TestMethod()]
        public void RemoveInventoryTest()
        {
            HomeTestConfiguration();

            InventoryModel inv = new InventoryModel();
            inv.Name = "SandalWood";
            var actual = homeControllerObj.RemoveInventory(inv.Name) as ViewResult;
            Assert.AreEqual("RemoveInventory", actual.ViewName);

        }

        [TestMethod()]
        public void SaveRemovedInventoryTest()
        {
            HomeTestConfiguration();

            InventoryModel inv = new InventoryModel();
            inv.Name = "SandalWood";
            var actual = homeControllerObj.SaveRemovedInventory(inv) as ViewResult;
            Assert.AreEqual("Success", actual.ViewName);
        }
    }
}