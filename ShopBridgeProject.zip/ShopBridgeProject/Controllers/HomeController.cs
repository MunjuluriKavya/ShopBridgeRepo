﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ShopBridgeDAL;
using ShopBridgeProject.Models;

namespace ShopBridgeProject.Controllers
{
    public class HomeController : Controller
    {
        ShopBridgeRepository sb = new ShopBridgeRepository();
        // GET: Home
        public ActionResult Index()
        {
            return View("Index");
        }

        public ActionResult AddInventory()
        {
            return View("AddInventory");
        }

        [HttpPost]
        public ActionResult AddInventory(Inventory inventory)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    int result = sb.AddItemToInventory(inventory.Name, inventory.Description, inventory.Price, inventory.Quantity, inventory.Category, inventory.Location, inventory.Status);
                    if (result == 0)
                    {
                        ViewBag.message = "Item with same name has been added already.";
                        return View("Error");
                    }
                    else if (result != -99)
                    {
                        ViewBag.message = "Item has been added to inventory successfully";
                        return View("Success");
                    }
                    else
                    {
                        ViewBag.message = "Couldnot add item to the inventory";
                        return View("Error");
                    }
                }
                catch (Exception)
                {
                    return View("Error");
                }
            }
            else
                return View("AddInventory");
        }

        public ActionResult ViewInventories()
        {
            try
            {
                List<Inventory> listOfInventories = sb.GetInventoriesUsingLinq();
                List<InventoryModel> lstInventory = new List<InventoryModel>();
                foreach (Inventory item in listOfInventories)
                {
                    InventoryModel inventory = new InventoryModel();
                    inventory.Id = item.Id;
                    inventory.Name = item.Name;
                    inventory.Description = item.Description;
                    inventory.Price = item.Price;
                    inventory.Quantity = item.Quantity;
                    inventory.Category = item.Category;
                    inventory.Location = item.Location;
                    inventory.Status = item.Status;
                    lstInventory.Add(inventory);

                }
                return View("ViewInventories", lstInventory);
            }
            catch (Exception e)
            {
                ViewBag.message = "Some error occurred";
                return View("Error");
            }
        }

        public ActionResult UpdateInventory(string name, decimal price, int quantity)
        {
            InventoryModel inventory = new InventoryModel();
            inventory.Name = name;
            inventory.Price = price;
            inventory.Quantity = quantity;
            return View("UpdateInventory", inventory);
        }

        [HttpPost]
        public ActionResult SaveUpdateInventory(InventoryModel inventory)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    int result = sb.UpdateItemOfInventory(inventory.Name, inventory.Price, inventory.Quantity);
                    if (result != -99)
                    {
                        ViewBag.message = "Inventory has been updated successfully.";
                        return View("Success");
                    }
                    else
                    {
                        return View("Error");
                    }
                }
                catch (Exception)
                {
                    return View("Error");
                }
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        public ActionResult RemoveInventory(string name)
        {
            InventoryModel inv = new InventoryModel();
            inv.Name = name;
            return View("RemoveInventory", inv);
        }

        // POST: Inventory/Delete
        [HttpPost]
        public ActionResult SaveRemovedInventory(InventoryModel inv)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    int result = sb.DeleteItemFromInventory(inv.Name);
                    if (result != -99)
                    {
                        ViewBag.message = "Inventory has been deleted successfully";
                        return View("Success");
                    }
                    else
                    {
                        return View("Error");
                    }
                }
                catch (Exception e)
                {
                    return View("Error");
                }
            }
            else
            {
                return RedirectToAction("Index");
            }
        }
    }
}