﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ShopBridgeDAL;

namespace ShopBridgeConsole1
{
    class Program
    {
        static void Main(string[] args)
        {
            ShopBridgeRepository sb = new ShopBridgeRepository();


            Console.WriteLine("Please enter your category \n 1. Update Item\n 2. Add Item\n 3. Delete Item");
            var input = Console.ReadLine();
            if (input.Equals("1"))
            {
                try
                {
                    var i = sb.UpdateItemOfInventory("Bread", 40, 10);
                    if (i == 1)
                    {
                        Console.WriteLine("Updated Successfully");

                    }
                    else
                    {
                        Console.WriteLine("Invalid Input");
                    }
                }
                catch
                {
                    Console.WriteLine("Give Proper Input");
                }

            }
            else if (input.Equals("2"))
            {
                try
                {
                    sb.AddItemToInventory("Lanthern", "Lamp", 10, 1, "RawMaterial", null, "NotSold");
                    Console.WriteLine("Added Successfully");
                }
                catch
                {
                    Console.WriteLine("Give Proper Input");
                }

            }
            else if (input.Equals("3"))
            {
                try
                {
                    sb.DeleteItemFromInventory("Lanthern");
                    Console.WriteLine("Deleted Successfully");
                }
                catch
                {
                    Console.WriteLine("Give Proper Input");
                }

            }

        }
    }
}
